ScreenshotPlugin
================

Example of plugin for TCPChat
